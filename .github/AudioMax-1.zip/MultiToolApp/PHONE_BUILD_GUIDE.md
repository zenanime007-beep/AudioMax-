# Phone மட்டும் வெச்சு APK Build பண்றது எப்படி (Computer இல்லாம)

## Step 1: GitHub Account
1. Phone browser-ல **github.com** போங்க
2. Sign up பண்ணுங்க (free) - email + password
3. Verify பண்ணுங்க

## Step 2: New Repository உருவாக்குங்க
1. GitHub app open ஆனதும், **"+"** icon click பண்ணுங்க → **"New repository"**
2. Repository name: `AudioMax`
3. **Public** ஆ வையுங்க (private-ஆ வேணும்னாலும் ஆகும், ஆனா free Actions minutes public-ல அதிகம்)
4. **Create repository** click பண்ணுங்க

## Step 3: Files Upload பண்றது
1. இந்த zip-ஐ முதலில் phone-ல **extract** பண்ணுங்க (Files app / ZArchiver போன்ற app வெச்சு)
2. GitHub repo page-ல **"Add file" → "Upload files"** click பண்ணுங்க
3. Extract பண்ண எல்லா files/folders-ஐயும் select பண்ணி upload பண்ணுங்க
   - **முக்கியம்:** `.github` folder (hidden folder) கூட upload ஆகணும் - இதுல தான் auto-build setup இருக்கு. Upload UI-ல hidden files காட்டாம இருந்தா, GitHub mobile app-ல "AudioMax" repo-க்குள்ள போய், manually `.github/workflows/build.yml` file-ஐ create பண்ணி, அதுல content paste பண்ணுங்க.
4. **Commit changes** click பண்ணுங்க

## Step 4: Build தானாகவே Start ஆகும்
1. Upload முடிந்ததும், repo-ல மேல **"Actions"** tab-க்கு போங்க
2. "Build APK" workflow run ஆகிட்டு இருக்கும் (yellow dot = running, green tick = success)
3. **5-10 நிமிடம்** காத்திருங்க

## Step 5: APK Download பண்றது
1. Build **green tick** ஆனதும், அந்த run-ஐ click பண்ணுங்க
2. கீழ போனா **"Artifacts"** section இருக்கும்
3. **"AudioMax-debug-apk"** click பண்ணி download பண்ணுங்க (இது zip-ஆ வரும், அதுக்குள்ள APK இருக்கும்)
4. Extract பண்ணி, APK-ஐ install பண்ணிக்கலாம் (phone settings-ல "Install unknown apps" allow பண்ணணும்)

## Problem வந்தா
- Build **red X** (fail) ஆனா, அந்த log-ஐ screenshot எடுத்து என்கிட்ட அனுப்புங்க, நான் fix பண்ணி தர்றேன்
- `.github/workflows/build.yml` upload ஆகலைன்னா build ஆரம்பிக்காது - இதை மறக்காம check பண்ணுங்க
