# MultiTool Player - Android App (Starter Code)

## இதுல என்ன இருக்கு (What's included)

1. **MainActivity** - Home screen, 3 features-க்கும் navigate பண்ணும்
2. **PlayerActivity + PlaybackService** - ExoPlayer வெச்சு video/audio play, background play support
3. **CutterActivity** - MediaExtractor/MediaMuxer வெச்சு file trim (lossless, no re-encode)
4. **EqualizerActivity** - Bass/Mid/Treble control + Volume booster (LoudnessEnhancer)
5. Dark theme with purple accent (unique color scheme) in `colors.xml` / `themes.xml`

## Build பண்றது எப்படி (How to build)

1. **Android Studio** download பண்ணுங்க (free): https://developer.android.com/studio
2. Android Studio open பண்ணி **"Open an existing project"** தேர்ந்தெடுங்க
3. இந்த `MultiToolApp` folder-ஐ select பண்ணுங்க
4. Gradle sync ஆகும் வரை காத்திருங்க (இது internet download பண்ணும், சின்ன wait ஆகலாம்)
5. மேல top menu-ல **Build > Build Bundle(s)/APK(s) > Build APK(s)** click பண்ணுங்க
6. APK file `app/build/outputs/apk/debug/app-debug.apk`-ல கிடைக்கும்
7. இந்த APK-ஐ phone-க்கு transfer பண்ணி install பண்ணிக்கலாம்

## இன்னும் செய்யணும் (Still to-do / not included yet)

- **Converter** (format change - mp3 to wav etc.) - இதுக்கு FFmpeg library வேணும், அடுத்த step-ல சேர்க்கலாம்
- **Noise Reducer** - audio processing library தேவை
- **Voice/Music Separator** (basic frequency-split version) - அடுத்த step
- **Theme picker UI** (multiple theme options for user to switch) - இப்போ ஒரே fixed theme தான் இருக்கு
- App icon (launcher icon) - default Android icon இப்போ இருக்கும், custom icon பிறகு சேர்க்கலாம்
- EqualizerActivity இப்போ standalone-ஆ இருக்கு; PlayerActivity-ஓட இணைக்கணும் (audioSessionId பாஸ் பண்ணி) அப்போதான் real-time-ஆ playing track-ல effect வேலை செய்யும்

## முக்கிய குறிப்பு (Important note)

இது ஒரு **starter/foundation code** - production-ready முழு app இல்ல. Core structure மற்றும் 3 main features (Player, Cutter, Equalizer) வேலை செய்யும்படி எழுதி இருக்கேன். மேலும் features சேர்க்க, testing பண்ண, UI polish பண்ண இன்னும் வேலை தேவைப்படும்.
