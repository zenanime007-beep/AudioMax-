package com.multitool.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnPlayer).setOnClickListener {
            startActivity(Intent(this, PlayerActivity::class.java))
        }

        findViewById<Button>(R.id.btnCutter).setOnClickListener {
            startActivity(Intent(this, CutterActivity::class.java))
        }

        findViewById<Button>(R.id.btnEqualizer).setOnClickListener {
            startActivity(Intent(this, EqualizerActivity::class.java))
        }
    }
}
