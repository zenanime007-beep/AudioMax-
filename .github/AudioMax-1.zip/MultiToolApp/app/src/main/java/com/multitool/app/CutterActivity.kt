package com.multitool.app

import android.media.MediaExtractor
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.nio.ByteBuffer

/**
 * Cuts a portion of an audio/video file using MediaExtractor + MediaMuxer.
 * This is a lossless "stream copy" trim (no re-encoding), similar to
 * how many lightweight cutter apps work. Fast and doesn't need FFmpeg.
 *
 * Note: For frame-accurate cuts on video (cutting mid-GOP), a proper
 * re-encode via FFmpeg/Media3 Transformer gives cleaner results, but
 * this approach works well for most audio files and many video files.
 */
class CutterActivity : AppCompatActivity() {

    private var selectedUri: Uri? = null
    private lateinit var tvSelectedFile: TextView
    private lateinit var tvStatus: TextView

    private val filePicker =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                selectedUri = it
                tvSelectedFile.text = it.lastPathSegment ?: "File selected"
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cutter)

        tvSelectedFile = findViewById(R.id.tvSelectedFile)
        tvStatus = findViewById(R.id.tvStatus)
        val etStart = findViewById<EditText>(R.id.etStart)
        val etEnd = findViewById<EditText>(R.id.etEnd)

        findViewById<Button>(R.id.btnChoose).setOnClickListener {
            filePicker.launch("*/*")
        }

        findViewById<Button>(R.id.btnCut).setOnClickListener {
            val uri = selectedUri
            if (uri == null) {
                Toast.makeText(this, "Choose a file first", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val startSec = etStart.text.toString().toLongOrNull()
            val endSec = etEnd.text.toString().toLongOrNull()
            if (startSec == null || endSec == null || endSec <= startSec) {
                Toast.makeText(this, "Enter valid start/end times", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            cutFile(uri, startSec * 1_000_000, endSec * 1_000_000) // microseconds
        }
    }

    private fun cutFile(uri: Uri, startUs: Long, endUs: Long) {
        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(this, uri, null)

            val outputDir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
            val outputFile = File(outputDir, "cut_${System.currentTimeMillis()}.mp4")
            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val trackCount = extractor.trackCount
            val indexMap = HashMap<Int, Int>()

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val dstIndex = muxer.addTrack(format)
                indexMap[i] = dstIndex
                extractor.selectTrack(i)
            }

            muxer.start()

            val buffer = ByteBuffer.allocate(1 * 1024 * 1024)
            val bufferInfo = android.media.MediaCodec.BufferInfo()

            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val sampleTime = extractor.sampleTime
                if (sampleTime == -1L || sampleTime > endUs) break

                buffer.clear()
                val sampleSize = extractor.readSampleData(buffer, 0)
                if (sampleSize < 0) break

                bufferInfo.offset = 0
                bufferInfo.size = sampleSize
                bufferInfo.presentationTimeUs = sampleTime - startUs
                bufferInfo.flags = extractor.sampleFlags

                muxer.writeSampleData(indexMap[trackIndex]!!, buffer, bufferInfo)
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            extractor.release()

            tvStatus.text = "Saved: ${outputFile.absolutePath}"
            Toast.makeText(this, "Cut file saved!", Toast.LENGTH_LONG).show()

        } catch (e: Exception) {
            tvStatus.text = "Error: ${e.message}"
        }
    }
}
