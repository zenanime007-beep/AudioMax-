package com.multitool.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

class PlayerActivity : AppCompatActivity() {

    private lateinit var player: ExoPlayer
    private lateinit var tvNowPlaying: TextView
    private lateinit var seekBar: SeekBar
    private val handler = Handler(Looper.getMainLooper())

    private val filePicker =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let { playFile(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        tvNowPlaying = findViewById(R.id.tvNowPlaying)
        seekBar = findViewById(R.id.seekBar)

        player = ExoPlayer.Builder(this).build()

        findViewById<Button>(R.id.btnChooseFile).setOnClickListener {
            // Accept both audio and video files
            filePicker.launch("*/*")
        }

        findViewById<Button>(R.id.btnPlayPause).setOnClickListener {
            if (player.isPlaying) player.pause() else player.play()
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) player.seekTo(progress.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        updateSeekBarLoop()
    }

    private fun playFile(uri: Uri) {
        tvNowPlaying.text = uri.lastPathSegment ?: "Playing..."
        val mediaItem = MediaItem.fromUri(uri)
        player.setMediaItem(mediaItem)
        player.prepare()
        player.play()

        // Start background playback service so audio continues
        // when the app is minimized (see PlaybackService.kt)
        val serviceIntent = Intent(this, PlaybackService::class.java)
        serviceIntent.putExtra("uri", uri.toString())
        startForegroundService(serviceIntent)
    }

    private fun updateSeekBarLoop() {
        handler.postDelayed({
            if (::player.isInitialized && player.duration > 0) {
                seekBar.max = player.duration.toInt()
                seekBar.progress = player.currentPosition.toInt()
            }
            updateSeekBarLoop()
        }, 500)
    }

    override fun onDestroy() {
        super.onDestroy()
        player.release()
        handler.removeCallbacksAndMessages(null)
    }
}
