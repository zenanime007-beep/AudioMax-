package com.multitool.app

import android.app.*
import android.content.Intent
import android.net.Uri
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem

/**
 * Keeps audio/video playing even when the app is minimized,
 * by running as a foreground service with a persistent notification.
 */
class PlaybackService : Service() {

    private var player: ExoPlayer? = null
    private val CHANNEL_ID = "multitool_playback_channel"
    private val NOTIF_ID = 101

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val uriString = intent?.getStringExtra("uri")
        uriString?.let {
            val mediaItem = MediaItem.fromUri(Uri.parse(it))
            player?.setMediaItem(mediaItem)
            player?.prepare()
            player?.play()
        }
        startForeground(NOTIF_ID, buildNotification())
        return START_STICKY
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("MultiTool Player")
            .setContentText("Playing in background")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Playback",
            NotificationManager.IMPORTANCE_LOW
        )
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
