package com.multitool.app

import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.os.Bundle
import android.widget.Button
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity

/**
 * Equalizer + Volume booster screen.
 * Uses Android's built-in audiofx APIs:
 *  - Equalizer: bass/mid/treble style band control
 *  - LoudnessEnhancer: boosts volume beyond 100% (careful with distortion)
 *
 * NOTE: Both effects attach to an active audio session ID. In a full app,
 * pass the session ID from the currently playing ExoPlayer instance
 * (player.audioSessionId) instead of 0, so the effect applies to that track.
 */
class EqualizerActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_equalizer)

        // audioSessionId = 0 here as placeholder; replace with player.audioSessionId
        // when wiring this screen up to the currently playing track.
        val audioSessionId = 0

        try {
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            loudnessEnhancer = LoudnessEnhancer(audioSessionId).apply { enabled = true }
        } catch (e: Exception) {
            // Effects unavailable until linked to a real playing session
        }

        val seekVolume = findViewById<SeekBar>(R.id.seekVolume)
        val seekBass = findViewById<SeekBar>(R.id.seekBass)
        val seekMid = findViewById<SeekBar>(R.id.seekMid)
        val seekTreble = findViewById<SeekBar>(R.id.seekTreble)

        seekVolume.setOnSeekBarChangeListener(simpleListener { progress ->
            // 100 = normal, up to 200 = +2000mB boost
            val gainMillibels = ((progress - 100) * 20).toInt()
            loudnessEnhancer?.setTargetGain(gainMillibels)
        })

        seekBass.setOnSeekBarChangeListener(simpleListener { progress ->
            setBandLevel(0, progress) // lowest frequency band
        })
        seekMid.setOnSeekBarChangeListener(simpleListener { progress ->
            setBandLevel(2, progress) // mid band (index depends on device, usually 5 bands total)
        })
        seekTreble.setOnSeekBarChangeListener(simpleListener { progress ->
            setBandLevel(4, progress) // highest frequency band
        })

        findViewById<Button>(R.id.btnPresetBass).setOnClickListener {
            setBandLevel(0, 900); setBandLevel(1, 700)
        }
        findViewById<Button>(R.id.btnPresetVocal).setOnClickListener {
            setBandLevel(2, 800); setBandLevel(3, 700)
        }
        findViewById<Button>(R.id.btnPresetFlat).setOnClickListener {
            for (i in 0..4) setBandLevel(i, 500)
        }
    }

    private fun setBandLevel(band: Int, progress: Int) {
        try {
            val eq = equalizer ?: return
            val range = eq.bandLevelRange // [minMillibels, maxMillibels]
            val minLevel = range[0]
            val maxLevel = range[1]
            // progress is 0-1000, map to actual min/max range of this device's equalizer
            val level = (minLevel + (progress / 1000f) * (maxLevel - minLevel)).toInt()
            if (band < eq.numberOfBands) {
                eq.setBandLevel(band.toShort(), level.toShort())
            }
        } catch (e: Exception) {
            // band index out of range on this device, ignore
        }
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(sb: SeekBar?) {}
        override fun onStopTrackingTouch(sb: SeekBar?) {}
    }

    override fun onDestroy() {
        super.onDestroy()
        equalizer?.release()
        loudnessEnhancer?.release()
    }
}
